1. download the .zip file
2. run the INSTALL.bat
3. run the START.bat and enjoy!